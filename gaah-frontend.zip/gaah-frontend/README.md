# GAAH Bookkeeping - Frontend Prototype

This is a Vue 3 + Vite prototype frontend for the GAAH Bookkeeping app.
It contains mock data and pages for:

- Dashboard
- Departments
- Book Details (view + add records locally)
- Login / Register (prototype)
- Settings (store API base locally)

## Quick start

1. Extract the zip and `cd` into `gaah-frontend`
2. Install dependencies:
   ```bash
   npm install
   ```
3. Run dev server:
   ```bash
   npm run dev
   ```
4. Build for production:
   ```bash
   npm run build
   ```

Set the backend base URL with environment variable `VITE_API_BASE` or in Settings page (prototype stores in localStorage).

This project intentionally uses mock/local data so you can finish backend deployment separately and then wire API calls.

