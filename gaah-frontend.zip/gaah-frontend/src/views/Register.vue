<template>
  <div>
    <h2>Register</h2>
    <p class="small">Prototype registration (local only).</p>

    <form @submit.prevent="register">
      <div style="margin-bottom:8px">
        <label>Name</label><br/>
        <input v-model="name" required />
      </div>
      <div style="margin-bottom:8px">
        <label>Email</label><br/>
        <input v-model="email" type="email" required />
      </div>
      <div style="margin-bottom:8px">
        <label>Password</label><br/>
        <input v-model="password" type="password" required />
      </div>
      <button type="submit">Register</button>
    </form>
  </div>
</template>

<script>
export default {
  name: 'Register',
  data() { return { name: '', email: '', password: '' } },
  methods: {
    register() {
      alert('Registered locally (prototype). Connect to backend to persist users.')
      this.$router.push('/login')
    }
  }
}
</script>
