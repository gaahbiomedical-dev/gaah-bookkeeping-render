<template>
  <div>
    <h2>Login</h2>
    <p class="small">Prototype authentication (no real backend). Use Register to create a mock user.</p>

    <form @submit.prevent="login">
      <div style="margin-bottom:8px">
        <label>Email</label><br/>
        <input v-model="email" type="email" required />
      </div>
      <div style="margin-bottom:8px">
        <label>Password</label><br/>
        <input v-model="password" type="password" required />
      </div>
      <button type="submit">Login</button>
    </form>
  </div>
</template>

<script>
export default {
  name: 'Login',
  data() { return { email: '', password: '' } },
  methods: {
    login() {
      alert('Login is a prototype. Wire this to your backend auth when ready.')
      this.$router.push('/')
    }
  }
}
</script>
