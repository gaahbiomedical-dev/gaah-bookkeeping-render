<template>
  <div>
    <h2>Dashboard</h2>
    <p class="small">Overview of total books and departments (prototype with mock data).</p>

    <section style="display:flex; gap:12px; margin-top:12px;">
      <div class="book-card" style="flex:1">
        <h3>Total Departments</h3>
        <p style="font-size:24px; margin:8px 0">{{ stats.departments }}</p>
      </div>
      <div class="book-card" style="flex:1">
        <h3>Total Books</h3>
        <p style="font-size:24px; margin:8px 0">{{ stats.books }}</p>
      </div>
      <div class="book-card" style="flex:1">
        <h3>Total Records</h3>
        <p style="font-size:24px; margin:8px 0">{{ stats.records }}</p>
      </div>
    </section>

    <section style="margin-top:18px;">
      <h3>Recent activity</h3>
      <ul>
        <li v-for="(r,i) in recent" :key="i">{{ r }}</li>
      </ul>
    </section>
  </div>
</template>

<script>
export default {
  name: 'Dashboard',
  data() {
    return {
      stats: { departments: 3, books: 7, records: 182 },
      recent: [
        'Added record to HR - Payroll book',
        'Imported 12 transactions to Sales - Ledger A',
        'Created new book: Procurement - 2025'
      ]
    }
  }
}
</script>

<style scoped>
h2 { margin-bottom:6px; }
</style>
