<template>
  <div>
    <h2>Departments</h2>
    <p class="small">List of departments and their books. Click a book to open details.</p>

    <div v-for="dept in departments" :key="dept.id" style="margin-top:14px">
      <h3>{{ dept.name }}</h3>
      <div style="display:flex; gap:10px; flex-wrap:wrap">
        <div class="book-card" v-for="book in dept.books" :key="book.id" style="width:220px">
          <strong>{{ book.title }}</strong>
          <div class="small">Records: {{ book.records }}</div>
          <div style="margin-top:8px">
            <router-link :to="{ name: 'BookDetails', params: { id: book.id } }">Open</router-link>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Departments',
  data() {
    return {
      departments: [
        { id: 1, name: 'Sales', books: [ { id: 's-1', title: 'Sales Ledger A', records: 48 }, { id: 's-2', title: 'Invoices - 2025', records: 23 } ] },
        { id: 2, name: 'HR', books: [ { id: 'h-1', title: 'Payroll', records: 55 } ] },
        { id: 3, name: 'Procurement', books: [ { id: 'p-1', title: 'Purchase Orders', records: 56 }, { id: 'p-2', title: 'Suppliers', records: 0 } ] },
      ]
    }
  }
}
</script>
