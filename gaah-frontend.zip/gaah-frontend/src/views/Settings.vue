<template>
  <div>
    <h2>Settings</h2>
    <p class="small">Optional settings and profile info (prototype).</p>

    <div style="margin-top:12px">
      <label>API Base URL (for deployment)</label><br/>
      <input v-model="apiBase" placeholder="http://localhost:8000" />
      <div style="margin-top:8px">
        <button @click="save">Save (stores in localStorage)</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Settings',
  data() {
    return { apiBase: localStorage.getItem('VITE_API_BASE') || '' }
  },
  methods: {
    save() {
      localStorage.setItem('VITE_API_BASE', this.apiBase)
      alert('Saved to localStorage. In deployment set VITE_API_BASE in environment or .env')
    }
  }
}
</script>
