<template>
  <div>
    <h2>Book Details</h2>
    <p class="small">Viewing book <strong>{{ book.title }}</strong> (mock data).</p>

    <section style="display:flex; gap:18px; margin-top:12px;">
      <div style="flex:1">
        <h3>Records</h3>
        <div v-if="records.length === 0">No records yet.</div>
        <div v-for="r in records" :key="r.id" class="book-card">
          <div><strong>{{ r.date }}</strong> — {{ r.summary }}</div>
          <div class="small">Amount: {{ r.amount }}</div>
        </div>
      </div>

      <aside style="width:360px">
        <h3>Add Record</h3>
        <form @submit.prevent="addRecord">
          <div style="margin-bottom:8px">
            <label>Date</label><br/>
            <input v-model="form.date" type="date" required />
          </div>
          <div style="margin-bottom:8px">
            <label>Summary</label><br/>
            <input v-model="form.summary" required />
          </div>
          <div style="margin-bottom:8px">
            <label>Amount</label><br/>
            <input v-model.number="form.amount" type="number" required />
          </div>
          <button type="submit">Add</button>
        </form>
      </aside>
    </section>
  </div>
</template>

<script>
export default {
  name: 'BookDetails',
  props: ['id'],
  data() {
    return {
      book: { id: this.id, title: 'Unknown Book' },
      records: [],
      form: { date: '', summary: '', amount: 0 }
    }
  },
  created() {
    // Mock: find book title from a simple map (in a real app fetch from API)
    const map = {
      's-1': 'Sales Ledger A',
      's-2': 'Invoices - 2025',
      'h-1': 'Payroll',
      'p-1': 'Purchase Orders',
      'p-2': 'Suppliers'
    }
    if (this.id && map[this.id]) this.book.title = map[this.id]
    // seed mock records
    this.records = [
      { id: 1, date: '2025-10-01', summary: 'Opening balance', amount: 0 },
      { id: 2, date: '2025-10-15', summary: 'Sample transaction', amount: 150.5 }
    ]
  },
  methods: {
    addRecord() {
      const newRec = { id: Date.now(), ...this.form }
      this.records.unshift(newRec)
      this.form = { date: '', summary: '', amount: 0 }
      alert('Record added (local mock). In production this would call your backend API.')
    }
  }
}
</script>
