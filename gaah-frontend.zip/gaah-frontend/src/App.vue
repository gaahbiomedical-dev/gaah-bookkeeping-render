<template>
  <div class="app-shell">
    <header>
      <div>
        <h1>GAAH Bookkeeping (Prototype)</h1>
        <div class="small">Multiple books across departments</div>
      </div>
      <div class="controls">
        <nav>
          <router-link to="/">Dashboard</router-link>
          <router-link to="/departments">Departments</router-link>
          <router-link to="/settings">Settings</router-link>
        </nav>
        <router-link to="/login">Login</router-link>
      </div>
    </header>

    <main>
      <router-view />
    </main>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style scoped>
small { color:#666; }
nav a.router-link-active { font-weight:700; }
</style>
